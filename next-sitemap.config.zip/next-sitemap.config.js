module.exports = {
  siteUrl: 'https://stockbrain.in',
  generateRobotsTxt: true, // (optional) generate robots.txt alongside your sitemap
  // distDir: 'build', // specify your custom build directory
  // other configurations can be added here
};
