 import HomeAll from '@/components/Home/HomeAll';


export default function Home() {
  
  return (
    <>
      <main>
        <HomeAll />
      </main>
    </>
  );
}
