// pages/index.js
import SipCalculator from '@/components/Home/SipCalculator';

const Home = () => {
  return (
    <div>
      <SipCalculator />
    </div>
  );
};

export default Home;
