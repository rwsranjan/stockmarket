

const nextConfig = {
  reactStrictMode: false,
  env: {
    BACKEND_URL: 'https://master.stockbrain.in/', //https://master.stockbrain.in/
    PUBLIC_URL: 'https://images.stockbrain.in/', //https://images.stockbrain.in/
    NEXTAUTH_URL: 'https://stockbrain.in/', //https://stockbrain.in/
    NEXTAUTH_SECRET: 'SanjeevranjanForSBIFM7903168538$'
  },
  // distDir: 'build',
  images: {
    loader: 'default',
    loaderFile: './lib/imageLoader.js',
    formats: ['image/webp'],
    remotePatterns: [
      {
        protocol: 'http',
        hostname: 'localhost',
        port: '5000',
        pathname: '**',
      },
    ],
  },
}

module.exports = nextConfig
